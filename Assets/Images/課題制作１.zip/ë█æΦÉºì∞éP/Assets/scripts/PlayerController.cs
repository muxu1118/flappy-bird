﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour {
    private Rigidbody2D rb2d;
    bool isDead = false;

    public GameObject Player;


    private void Awake()
    {
        rb2d = gameObject.GetComponent<Rigidbody2D>();
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (isDead) { return; }
        //死亡状態
        isDead = true;
    }
    
    public bool IsDead()
    {
        return isDead;
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Flap();
        }
    }
    public void Flap()
    {
        //死亡状態の確認
        if (isDead) { return; }

        Player.GetComponent<Rigidbody2D>().velocity = new Vector3(0, 5, 0);
    }
    public void SetKinematicFlg(bool _fig) {
        rb2d.isKinematic = _fig;
    }
}
