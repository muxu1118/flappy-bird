﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Moveboard : MonoBehaviour {


    // Use this for initialization
    void Update()
    {
        transform.Translate(-0.05f, 0, 0);//速度
        if (transform.position.x < -5f) //エンドポイント
        {
            float y = Random.Range(-1f, 3f);//上下ランダム

            transform.position = new Vector3(5f, y, 0);//スタートポイント
        }
    }

    

}
