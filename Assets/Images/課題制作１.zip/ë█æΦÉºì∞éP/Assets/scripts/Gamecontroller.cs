﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using UnityEngine.SceneManagement;
public class Gamecontroller : MonoBehaviour {
    
    public GameObject scoreText;

    //ゲームのステート

    enum State
    {
        Ready,  //ゲーム開始
        Play,   //ゲーム中
        GameOver    //ゲームオーバー
    };

    State gameState;    //現在のゲームの状態

    [SerializeField]
    PlayerController player; //プレイヤー
    [SerializeField]
    scrollobject BOARDs;

    

    void LateUpdate()
    {
        //ゲームステートに応じてイベント
        switch (gameState) {
            case State.Ready:   //ゲーム開始
                //タッチしたらゲームスタート
                if (Input.GetMouseButtonDown(0)) {
                    GameState();
                }
                break;
            case State.Play:     //ゲーム中
                //プレイヤーが死亡しているかチェック
                if (player.IsDead()) {
                    GameOver();
                }
                break;
            case State.GameOver:    //ゲームオーバー
                if (Input.GetMouseButtonDown(0)) {
                    Reload();
                }

                break;
            default:
                break;
        }
    }

    private void Start()
    {
        GameReady();
    }
    void GameState() {
        //ゲーム中の状態へ変更
        gameState = State.Play;

        //各オブジェクトを有効にする
        player.SetKinematicFlg(false);
        BOARDs.SetActive(true);

        //最初の一回だけはばたかせる
        player.Flap();
    }
    void GameReady() {
        //ゲーム開始状態へ変更;
        gameState = State.Ready;

        //各オブジェクトを無効にする
        player.SetKinematicFlg(true);
        BOARDs.SetActive(false);
    }

    void GameOver() {
        gameState = State.GameOver;
        //シーン中のすべてのスクロールオブジェクトコンポーネントを探し出す
        scrollobject[] scrollobjects = GameObject.FindObjectsOfType<scrollobject>();
        //
        foreach (scrollobject sc in scrollObjects) {
            scrollobject.endbled = false;
        }
    }

    void Reload() {
        Scene loadscene = SceneManager.GetActiveScene();
        SceneManager.LoadScene(loadscene.name);
    }
    void OnTriggerEnter2D(Collider2D col){
        //Score(GUIText)のScoreUpメソッドを呼び出す
        scoreText.SendMessage("ScoreUp", 1);
    }
    
}
